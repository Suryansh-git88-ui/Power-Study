import React, { useState, useEffect, useRef, useCallback } from 'react';
import AnimatedBackground from './components/AnimatedBackground';
import RobotMascot from './components/RobotMascot';
import LoginForm from './components/LoginForm';
import ForgotPasswordForm from './components/ForgotPasswordForm';
import SignupForm from './components/SignupForm';
import Dashboard from './components/Dashboard';
import { useAuth } from './hooks/useAuth';

type AuthView = 'login' | 'forgot' | 'signup';

function App() {
  const [currentView, setCurrentView] = useState<AuthView>('login');
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isLoaded, setIsLoaded] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const { user, loading } = useAuth();

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (rect) {
      const x = (e.clientX - rect.left - rect.width / 2) / rect.width;
      const y = (e.clientY - rect.top - rect.height / 2) / rect.height;
      setMousePosition({ x: x * 0.5, y: y * 0.5 });
    }
  }, []);

  useEffect(() => {
    let rafId: number;
    const throttledMouseMove = (e: MouseEvent) => {
      if (rafId) return;
      rafId = requestAnimationFrame(() => {
        handleMouseMove(e);
        rafId = 0;
      });
    };

    window.addEventListener('mousemove', throttledMouseMove, { passive: true });
    return () => {
      window.removeEventListener('mousemove', throttledMouseMove);
      if (rafId) cancelAnimationFrame(rafId);
    };
  }, [handleMouseMove]);

  // Show loading screen while checking auth state
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-white text-lg">Loading Power Study...</p>
        </div>
      </div>
    );
  }

  // Show dashboard if user is authenticated
  if (user) {
    return <Dashboard />;
  }

  const renderCurrentForm = () => {
    switch (currentView) {
      case 'forgot':
        return <ForgotPasswordForm onBack={() => setCurrentView('login')} />;
      case 'signup':
        return <SignupForm onBack={() => setCurrentView('login')} />;
      default:
        return (
          <LoginForm
            onSwitchToForgot={() => setCurrentView('forgot')}
            onSwitchToSignup={() => setCurrentView('signup')}
          />
        );
    }
  };

  const getTitle = () => {
    switch (currentView) {
      case 'forgot':
        return 'Password Recovery';
      case 'signup':
        return 'Join Power Study';
      default:
        return 'Authentication';
    }
  };

  return (
    <div 
      ref={containerRef}
      className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden"
      style={{
        transform: `translate(${mousePosition.x * 5}px, ${mousePosition.y * 5}px)`,
        transition: 'transform 0.1s ease-out'
      }}
    >
      <AnimatedBackground />

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div 
          className={`w-full max-w-md transform transition-all duration-700 ${
            isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
          }`}
        >
          {/* Logo and Title */}
          <div className="text-center mb-8">
            <div className="relative inline-block">
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent animate-glow-text">
                Power Study
              </h1>
              <div className="text-lg md:text-xl text-cyan-300 font-semibold mt-2 animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
                {getTitle()}
              </div>
              
              {/* Particle Trail - Only show on login */}
              {currentView === 'login' && (
                <div className="absolute -top-2 -right-2">
                  {[...Array(3)].map((_, i) => (
                    <div
                      key={i}
                      className="absolute w-1 h-1 bg-cyan-400 rounded-full animate-particle-trail will-change-transform"
                      style={{
                        animationDelay: `${i * 0.3}s`
                      }}
                    ></div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Robot Mascot - Only show on login */}
          {currentView === 'login' && <RobotMascot mousePosition={mousePosition} />}

          {/* Form Panel */}
          <div 
            className={`backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-8 shadow-2xl transform transition-all duration-500 ${
              isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
            }`}
            style={{ animationDelay: '0.5s' }}
          >
            {renderCurrentForm()}
          </div>

          {/* Security Badge - Only show on login */}
          {currentView === 'login' && (
            <div className="text-center mt-6 opacity-80">
              <div className="inline-flex items-center gap-2 text-xs text-gray-400">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                Secured by Firebase Authentication
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;