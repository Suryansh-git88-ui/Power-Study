import React, { memo } from 'react';
import { Bot } from 'lucide-react';

interface RobotMascotProps {
  mousePosition: { x: number; y: number };
}

const RobotMascot = memo(({ mousePosition }: RobotMascotProps) => {
  return (
    <div className="flex justify-center mb-8">
      <div 
        className="relative animate-hover cursor-pointer transform transition-transform duration-300 hover:scale-110 will-change-transform"
        style={{
          transform: `translateX(${mousePosition.x * 3}px) translateY(${mousePosition.y * 3}px)`
        }}
      >
        <div className="relative">
          <Bot 
            size={80} 
            className="text-cyan-400 drop-shadow-2xl animate-bot-glow" 
          />
          <div className="absolute top-6 left-6 w-2 h-2 bg-green-400 rounded-full animate-blink"></div>
          <div className="absolute top-6 right-6 w-2 h-2 bg-green-400 rounded-full animate-blink" style={{ animationDelay: '0.1s' }}></div>
        </div>
        
        {/* Bot Glow Effect */}
        <div className="absolute inset-0 bg-cyan-400/20 rounded-full blur-xl animate-pulse"></div>
      </div>
    </div>
  );
});

RobotMascot.displayName = 'RobotMascot';

export default RobotMascot;