import React, { useState } from 'react';
import { User, Lock, Eye, EyeOff, Zap, AlertCircle } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

interface LoginFormProps {
  onSwitchToForgot: () => void;
  onSwitchToSignup: () => void;
}

export default function LoginForm({ onSwitchToForgot, onSwitchToSignup }: LoginFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  
  const { login, loading, error } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(formData.email, formData.password);
      // User will be redirected automatically via auth state change
    } catch (error) {
      // Error is handled by the useAuth hook
      console.error('Login failed:', error);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Error Message */}
      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Email Field */}
      <div className="relative group">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <User className="h-5 w-5 text-cyan-400 group-focus-within:text-cyan-300 transition-colors duration-200" />
        </div>
        <input
          type="email"
          value={formData.email}
          onChange={(e) => handleInputChange('email', e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400 transition-all duration-200 hover:bg-white/10 focus:bg-white/10 will-change-transform"
          placeholder="Email Address"
          required
          disabled={loading}
        />
        <label className="absolute left-10 -top-2 px-2 text-xs text-cyan-300 bg-slate-900/80 rounded transition-all duration-200 opacity-0 group-focus-within:opacity-100 pointer-events-none">
          Email Address
        </label>
      </div>

      {/* Password Field */}
      <div className="relative group">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Lock className="h-5 w-5 text-cyan-400 group-focus-within:text-cyan-300 transition-colors duration-200" />
        </div>
        <input
          type={showPassword ? "text" : "password"}
          value={formData.password}
          onChange={(e) => handleInputChange('password', e.target.value)}
          className="w-full pl-10 pr-12 py-3 bg-white/5 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400 transition-all duration-200 hover:bg-white/10 focus:bg-white/10 will-change-transform"
          placeholder="Password"
          required
          disabled={loading}
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute inset-y-0 right-0 pr-3 flex items-center text-cyan-400 hover:text-cyan-300 transition-colors duration-200"
          disabled={loading}
        >
          {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
        </button>
        <label className="absolute left-10 -top-2 px-2 text-xs text-cyan-300 bg-slate-900/80 rounded transition-all duration-200 opacity-0 group-focus-within:opacity-100 pointer-events-none">
          Password
        </label>
      </div>

      {/* Login Button */}
      <button
        type="submit"
        disabled={loading}
        className="w-full py-3 px-4 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-blue-600 hover:to-cyan-600 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-[1.02] disabled:hover:scale-100 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 flex items-center justify-center gap-2 will-change-transform"
      >
        {loading ? (
          <>
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            Signing In...
          </>
        ) : (
          <>
            <Zap className="w-5 h-5" />
            Login to Power Study
          </>
        )}
      </button>

      {/* Links */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 text-sm">
        <button
          type="button"
          onClick={onSwitchToForgot}
          disabled={loading}
          className="text-cyan-300 hover:text-cyan-200 transition-colors duration-200 hover:underline decoration-cyan-400 underline-offset-4 disabled:opacity-50"
        >
          Forgot Password?
        </button>
        <button
          type="button"
          onClick={onSwitchToSignup}
          disabled={loading}
          className="text-purple-300 hover:text-purple-200 transition-colors duration-200 hover:underline decoration-purple-400 underline-offset-4 disabled:opacity-50"
        >
          Create Account
        </button>
      </div>
    </form>
  );
}