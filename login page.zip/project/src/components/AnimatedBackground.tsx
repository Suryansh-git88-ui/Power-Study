import React, { memo } from 'react';

const AnimatedBackground = memo(() => {
  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Binary Code Animation - Reduced count for performance */}
      <div className="absolute inset-0 opacity-10">
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute text-cyan-400 font-mono text-xs animate-binary-fall will-change-transform"
            style={{
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${4 + Math.random() * 3}s`
            }}
          >
            {Math.random().toString(2).substr(2, 6)}
          </div>
        ))}
      </div>

      {/* Circuit Lines - Optimized */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent animate-pulse-slow"></div>
        <div className="absolute top-3/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-purple-500/50 to-transparent animate-pulse-slow" style={{ animationDelay: '2s' }}></div>
        <div className="absolute left-1/4 top-0 w-px h-full bg-gradient-to-b from-transparent via-blue-500/50 to-transparent animate-pulse-slow" style={{ animationDelay: '1s' }}></div>
        <div className="absolute right-1/4 top-0 w-px h-full bg-gradient-to-b from-transparent via-indigo-500/50 to-transparent animate-pulse-slow" style={{ animationDelay: '3s' }}></div>
      </div>

      {/* Floating Particles - Reduced count */}
      <div className="absolute inset-0">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400/60 rounded-full animate-float will-change-transform"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${4 + Math.random() * 2}s`
            }}
          ></div>
        ))}
      </div>
    </div>
  );
});

AnimatedBackground.displayName = 'AnimatedBackground';

export default AnimatedBackground;