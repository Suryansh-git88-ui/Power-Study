import React, { useState } from 'react';
import { User, Mail, Lock, Eye, EyeOff, UserPlus, ArrowLeft, AlertCircle } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

interface SignupFormProps {
  onBack: () => void;
}

export default function SignupForm({ onBack }: SignupFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  
  const { signup, loading, error } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      alert('Passwords do not match!');
      return;
    }

    if (formData.password.length < 6) {
      alert('Password must be at least 6 characters long!');
      return;
    }

    try {
      await signup(formData.email, formData.password, formData.fullName);
      // User will be redirected automatically via auth state change
    } catch (error) {
      // Error is handled by the useAuth hook
      console.error('Signup failed:', error);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const passwordsMatch = formData.password === formData.confirmPassword;
  const showPasswordMismatch = formData.confirmPassword.length > 0 && !passwordsMatch;

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold text-white mb-2">Create Account</h3>
        <p className="text-gray-300 text-sm">
          Join Power Study and unlock AI-powered learning tools
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Error Message */}
        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Full Name Field */}
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <User className="h-5 w-5 text-cyan-400 group-focus-within:text-cyan-300 transition-colors duration-200" />
          </div>
          <input
            type="text"
            value={formData.fullName}
            onChange={(e) => handleInputChange('fullName', e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400 transition-all duration-200 hover:bg-white/10 focus:bg-white/10 will-change-transform"
            placeholder="Full Name"
            required
            disabled={loading}
          />
          <label className="absolute left-10 -top-2 px-2 text-xs text-cyan-300 bg-slate-900/80 rounded transition-all duration-200 opacity-0 group-focus-within:opacity-100 pointer-events-none">
            Full Name
          </label>
        </div>

        {/* Email Field */}
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Mail className="h-5 w-5 text-cyan-400 group-focus-within:text-cyan-300 transition-colors duration-200" />
          </div>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => handleInputChange('email', e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white/5 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400 transition-all duration-200 hover:bg-white/10 focus:bg-white/10 will-change-transform"
            placeholder="Email Address"
            required
            disabled={loading}
          />
          <label className="absolute left-10 -top-2 px-2 text-xs text-cyan-300 bg-slate-900/80 rounded transition-all duration-200 opacity-0 group-focus-within:opacity-100 pointer-events-none">
            Email Address
          </label>
        </div>

        {/* Password Field */}
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Lock className="h-5 w-5 text-cyan-400 group-focus-within:text-cyan-300 transition-colors duration-200" />
          </div>
          <input
            type={showPassword ? "text" : "password"}
            value={formData.password}
            onChange={(e) => handleInputChange('password', e.target.value)}
            className="w-full pl-10 pr-12 py-3 bg-white/5 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 focus:border-cyan-400 transition-all duration-200 hover:bg-white/10 focus:bg-white/10 will-change-transform"
            placeholder="Password"
            required
            minLength={6}
            disabled={loading}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-cyan-400 hover:text-cyan-300 transition-colors duration-200"
            disabled={loading}
          >
            {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
          <label className="absolute left-10 -top-2 px-2 text-xs text-cyan-300 bg-slate-900/80 rounded transition-all duration-200 opacity-0 group-focus-within:opacity-100 pointer-events-none">
            Password
          </label>
        </div>

        {/* Confirm Password Field */}
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Lock className="h-5 w-5 text-cyan-400 group-focus-within:text-cyan-300 transition-colors duration-200" />
          </div>
          <input
            type={showConfirmPassword ? "text" : "password"}
            value={formData.confirmPassword}
            onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
            className={`w-full pl-10 pr-12 py-3 bg-white/5 border rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 transition-all duration-200 hover:bg-white/10 focus:bg-white/10 will-change-transform ${
              showPasswordMismatch 
                ? 'border-red-500/50 focus:ring-red-400/50 focus:border-red-400' 
                : 'border-white/20 focus:ring-cyan-400/50 focus:border-cyan-400'
            }`}
            placeholder="Confirm Password"
            required
            minLength={6}
            disabled={loading}
          />
          <button
            type="button"
            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-cyan-400 hover:text-cyan-300 transition-colors duration-200"
            disabled={loading}
          >
            {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
          <label className="absolute left-10 -top-2 px-2 text-xs text-cyan-300 bg-slate-900/80 rounded transition-all duration-200 opacity-0 group-focus-within:opacity-100 pointer-events-none">
            Confirm Password
          </label>
          {showPasswordMismatch && (
            <p className="text-red-400 text-xs mt-1 ml-2">Passwords do not match</p>
          )}
        </div>

        {/* Terms and Conditions */}
        <div className="flex items-start gap-3 text-sm">
          <input
            type="checkbox"
            id="terms"
            required
            disabled={loading}
            className="mt-1 w-4 h-4 text-cyan-400 bg-transparent border-2 border-white/20 rounded focus:ring-cyan-400/50 focus:ring-2"
          />
          <label htmlFor="terms" className="text-gray-300 leading-relaxed">
            I agree to the{' '}
            <a href="#" className="text-cyan-300 hover:text-cyan-200 underline decoration-cyan-400 underline-offset-2">
              Terms of Service
            </a>{' '}
            and{' '}
            <a href="#" className="text-cyan-300 hover:text-cyan-200 underline decoration-cyan-400 underline-offset-2">
              Privacy Policy
            </a>
          </label>
        </div>

        {/* Create Account Button */}
        <button
          type="submit"
          disabled={loading || showPasswordMismatch}
          className="w-full py-3 px-4 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-blue-600 hover:to-cyan-600 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-[1.02] disabled:hover:scale-100 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 flex items-center justify-center gap-2 will-change-transform"
        >
          {loading ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              Creating Account...
            </>
          ) : (
            <>
              <UserPlus className="w-5 h-5" />
              Create Account
            </>
          )}
        </button>

        {/* Back Button */}
        <button
          type="button"
          onClick={onBack}
          disabled={loading}
          className="w-full py-3 px-4 bg-transparent border border-white/20 hover:bg-white/5 text-white font-semibold rounded-lg transition-all duration-200 transform hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-white/20 flex items-center justify-center gap-2 disabled:opacity-50"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Login
        </button>
      </form>
    </div>
  );
}